CTF на Физтехе
==============

## Прошедшие занятия

**21 сентября.** [Вводное занятие.](https://github.com/vladvis/mipt-ctf/tree/master/01-intro) [Основы реверс инжиниринга.](https://github.com/vladvis/mipt-ctf/tree/master/02-reverse/01-intro)

## Ближайшее занятие

**28 сентября.** [Инструменты для реверса. Отладка.](https://github.com/vladvis/mipt-ctf/tree/master/02-reverse/02-debug)
